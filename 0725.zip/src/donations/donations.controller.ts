import { Controller, Get, Post, Body } from '@nestjs/common';
import { DonationsService } from './donations.service';
import { Donation } from './donations.entity';


@Controller('dm-api/donations')
export class DonationsController {
  constructor(private readonly donationsService: DonationsService) {}

  @Get()
  findAll(): Promise<Donation[]> {
    return this.donationsService.findAll();
  }

  @Post()
  save(@Body() donation: Donation): Promise<Donation> {
    return this.donationsService.saveDonation(donation);
  }

}
