import { Entity, Column, PrimaryColumn } from 'typeorm';

@Entity()
export class Donation {
  
  @PrimaryColumn({name: 'donation_id'})
  donationId: number;

  @Column({name: 'payer_name'})
	payerName: string;

    @Column({name: 'donation_date'})
	donationDate: string;
	
    @Column({name: 'payment_type'})
    paymentType: string;

    @Column()
	amount: number;

    @Column({name: 'purpose_type'})
	purposeType: string;

    @Column({name: 'receiver_name'})
	receiverName: string;

    @Column({name: 'inserted_by'})
    insertedBy: string;

    @Column({name: 'inserted_ts'})
    insertedAt: string;
}