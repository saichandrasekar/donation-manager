import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { Donation } from './donations.entity';

@Injectable()
export class DonationsService {
  
  constructor(
    @InjectRepository(Donation)
    private readonly donationsRepository: Repository<Donation>
  ) {}

  async findAll(): Promise<Donation[]>{
    return this.donationsRepository.find();
  }

  async saveDonation(donation: Donation): Promise<Donation>{
    donation.insertedBy = 'admin';
    donation.insertedAt = new Date().toJSON();
    this.donationsRepository.save(donation);
    console.log(donation.donationId)
    return donation;
  }

}
