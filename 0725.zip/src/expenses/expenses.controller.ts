import { Controller, Get, Post, Body } from '@nestjs/common';
import { Expense } from './expense.entity';
import { ExpensesService } from './expenses.service';



@Controller('dm-api/expenses')
export class ExpensesController {
  constructor(private readonly expensesService: ExpensesService) {}

  @Get()
  findAll(): Promise<Expense[]> {
    return this.expensesService.findAll();
  }

  @Post()
  save(@Body() expense: Expense): Promise<Expense> {
    return this.expensesService.saveExpense(expense);
  }

}
