import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { Expense } from './expense.entity';

@Injectable()
export class ExpensesService {
  
  constructor(
    @InjectRepository(Expense)
    private readonly expensesRepository: Repository<Expense>
  ) {}

  async findAll(): Promise<Expense[]>{
    return this.expensesRepository.find();
  }

  async saveExpense(expense: Expense): Promise<Expense>{
    expense.insertedBy = 'admin';
    expense.insertedAt = new Date().toJSON();
    return this.expensesRepository.save(expense);
  }

}
