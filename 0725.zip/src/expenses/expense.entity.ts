import { Entity, Column, PrimaryGeneratedColumn, PrimaryColumn } from 'typeorm';

@Entity()
export class Expense {
  
  @PrimaryColumn({name: 'expense_id'})
  expenseId: number;

  @Column({name: 'expense_type'})
	expenseType: string;

    @Column({name: 'expense_date'})
	expenseDate: string;

    @Column()
	amount: number;

    @Column({name: 'document_name'})
	documentName: string;

    @Column({name: 'document_path'})
	documentPath: string;

    @Column({name: 'inserted_by'})
    insertedBy: string;

    @Column({name: 'inserted_ts'})
    insertedAt: string;
}