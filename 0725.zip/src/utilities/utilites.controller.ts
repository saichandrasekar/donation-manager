import { Controller, Get, Post } from '@nestjs/common';
import { UtilitiesService } from './utilities.service';


@Controller('dm-api/utility')
export class UtilitiesController {
  constructor(private readonly utilitiesService: UtilitiesService) {}

  @Post('upload')
  uploadFile(){
    this.utilitiesService.uploadFile();
  }

  @Get('download/data')
  downloadDataDump(): string{
    return ""
  }

}
