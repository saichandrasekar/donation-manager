import { Injectable } from '@nestjs/common';

@Injectable()
export class UtilitiesService {
  
  constructor() {}

  async uploadFile(){
  }

}
