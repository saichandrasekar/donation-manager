import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { UserDetails } from './userDetails.entity';



@Injectable()
export class UserDetailsService {
  
  constructor(
    @InjectRepository(UserDetails)
    private readonly userDetailsRepository: Repository<UserDetails>
  ) {}

  async find(userDetail: UserDetails): Promise<UserDetails>{
    return this.userDetailsRepository.findOneBy({
      userName: userDetail.userName,
      password: userDetail.password
    });
  }

}
