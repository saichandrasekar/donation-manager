import { Controller, Post, Body } from '@nestjs/common';
import { UserDetailsService } from './userDetails.service';
import { UserDetails } from './userDetails.entity';

@Controller('dm-api/users')
export class UserDetailsController {
  constructor(private readonly userDetailsService: UserDetailsService) {}

  @Post()
  find(@Body() userDetail: UserDetails): Promise<UserDetails> {
    return this.userDetailsService.find(userDetail);
  }

}
