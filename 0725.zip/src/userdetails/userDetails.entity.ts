import { Entity, Column, PrimaryColumn } from 'typeorm';

@Entity()
export class UserDetails{
  
  @PrimaryColumn({name: 'user_id'})
  userId: number;

  @Column({name: 'user_name'})
	userName: string;

    @Column({name: 'pwd_val'})
    password: string;

    @Column({name: 'inserted_by'})
    insertedBy: string;

    @Column({name: 'inserted_ts'})
    insertedAt: string;
}