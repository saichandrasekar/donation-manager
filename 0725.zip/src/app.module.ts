import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { Donation } from './donations/donations.entity';
import { Expense } from './expenses/expense.entity';
import { DonationsModule } from './donations/donations.module';
import { ExpensesModule } from './expenses/expenses.module';
import { UtilitiesService } from './utilities/utilities.service';
import { UtilitiesController } from './utilities/utilites.controller';
import { UserDetails } from './userdetails/userDetails.entity';
import { UserDetailsModule } from './userdetails/userDetails.module';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: 'localhost',
      port: 5432,
      username: 'postgres',
      password: 'admin123',
      database: 'postgres',
      entities: [Donation, Expense, UserDetails],
      synchronize: false,
    }),
    DonationsModule,
    ExpensesModule,
    UserDetailsModule
  ],
  controllers: [AppController, UtilitiesController],
  providers: [AppService, UtilitiesService],
})
export class AppModule {
  constructor(private dataSource: DataSource) {}
}
