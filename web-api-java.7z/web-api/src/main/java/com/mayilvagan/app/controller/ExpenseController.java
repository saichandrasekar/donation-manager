package com.mayilvagan.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mayilvagan.app.entity.Expense;
import com.mayilvagan.app.repository.ExpenseRepository;

@RestController
public class ExpenseController {
	
	@Autowired
	private ExpenseRepository expenseRepository;
	
	@GetMapping("/expenses")
	public @ResponseBody Iterable<Expense> getExpenses(){
		return expenseRepository.findAll();
	}

}
