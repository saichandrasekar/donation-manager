package com.mayilvagan.app.viewobject;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class DonationVO {
	private Long donationId;

	private String payerName, paymentType, purposeType, receiverName, insertedBy;
	private BigDecimal amount;
	private LocalDateTime donationDate;
	private LocalDateTime insertTS;
	
	
}
