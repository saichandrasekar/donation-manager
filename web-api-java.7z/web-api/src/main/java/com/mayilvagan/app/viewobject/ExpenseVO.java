package com.mayilvagan.app.viewobject;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class ExpenseVO {
	private Long expenseId;

	private LocalDateTime expenseDate;
	private BigDecimal amount;
	private String documentName;
	private String documentPath;
	private String insertedBy;
	private LocalDateTime insertTS;
	
	public Long getExpenseId() {
		return expenseId;
	}
	public LocalDateTime getExpenseDate() {
		return expenseDate;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public String getDocumentName() {
		return documentName;
	}
	public String getDocumentPath() {
		return documentPath;
	}
	public String getInsertedBy() {
		return insertedBy;
	}
	public LocalDateTime getInsertTS() {
		return insertTS;
	}
	
	
}
