package com.mayilvagan.app.viewobject;

import java.util.List;

public class BalanceSummaryVO {
	
	private List<DonationVO> donations;
	
	private List<ExpenseVO> expenses;

	public List<DonationVO> getDonations() {
		return donations;
	}

	public void setDonations(List<DonationVO> donations) {
		this.donations = donations;
	}

	public List<ExpenseVO> getExpenses() {
		return expenses;
	}

	public void setExpenses(List<ExpenseVO> expenses) {
		this.expenses = expenses;
	}
	
	

}
