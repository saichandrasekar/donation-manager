package com.mayilvagan.app.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MonitorController {

	  @GetMapping("/isalive")
	    String home() {
	        return "Donation Manager is up and running...!";
	    }
}
