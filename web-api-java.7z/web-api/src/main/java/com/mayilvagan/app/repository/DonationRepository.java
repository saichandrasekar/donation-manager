package com.mayilvagan.app.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.mayilvagan.app.entity.Donation;

@RepositoryRestResource(collectionResourceRel = "donation", path = "donation")
public interface DonationRepository extends PagingAndSortingRepository<Donation, Long>, CrudRepository<Donation,Long> {

	List<Donation> findByPayerName(@Param("payerName") String payerName);

}