package com.mayilvagan.app.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mayilvagan.app.viewobject.BalanceSummaryVO;

@RestController
public class BalanceSummaryController {

	@GetMapping("/balancesummary")
	public @ResponseBody BalanceSummaryVO getBalanceSummary() {
		BalanceSummaryVO balanceSummaryVO = new BalanceSummaryVO();
		return balanceSummaryVO;
	}
}
