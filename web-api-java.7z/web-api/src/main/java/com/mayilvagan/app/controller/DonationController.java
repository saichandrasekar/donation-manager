package com.mayilvagan.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mayilvagan.app.entity.Donation;
import com.mayilvagan.app.repository.DonationRepository;


@RestController
public class DonationController {
	
	@Autowired
	private DonationRepository donationRepository;
	
	
	@GetMapping("/donations")
	public @ResponseBody Iterable<Donation> getDonations(){
		return donationRepository.findAll();
	}
	
	public @ResponseBody HttpEntity<Donation> addDonation() {		
		return null;
	}

}
