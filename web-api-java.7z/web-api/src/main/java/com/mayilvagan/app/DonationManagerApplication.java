package com.mayilvagan.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.mayilvagan")
public class DonationManagerApplication {


    /**
     * @param args
     */
    public static void main(String[] args) {
        SpringApplication.run(DonationManagerApplication.class, args);
    }

}

